# Blogging-Application
Blogging web application, writers can post their blogs and readers can read comment and give review.
