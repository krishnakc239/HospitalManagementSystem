package com.edu.mum.controller;

import com.edu.mum.domain.Patient;
import com.edu.mum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistrationController {

    @Autowired
    private  UserService userService;

    @RequestMapping(value = "/register")
    public String register(Model model) {
        model.addAttribute("patient", new Patient());
        return "views/home/registeration";
    }



    @PostMapping(value = "/checkRegister")
    public ModelAndView checkRegister(@ModelAttribute("patient") Patient patient, BindingResult bindingResult) {
        ModelAndView mav = new ModelAndView();
        if (bindingResult.hasErrors()){
            mav.addObject("message", "registration failed");
            mav.setViewName("views/home/registeration");
        }else {
            userService.save(patient);
            mav.setViewName("redirect:/showPatients");
        }
        return mav;

    }
}
