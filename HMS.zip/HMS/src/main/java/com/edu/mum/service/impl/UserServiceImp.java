package com.edu.mum.service.impl;

import com.edu.mum.domain.Patient;
import com.edu.mum.repository.UserRepository;
import com.edu.mum.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImp implements UserService {

    private final UserRepository userRepository;


    @Autowired
    public UserServiceImp(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<Patient> getAll() {
        return userRepository.findAll();
    }

    @Override
    public Patient save(Patient patient) {
        return userRepository.save(patient);
    }
}
