package com.edu.mum.service;

import com.edu.mum.domain.Patient;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<Patient> getAll();
    Patient save(Patient patient);
}
