package com.edu.mum.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "patients")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_id")
    private Long id;

    @Column(name = "email_address")
    @Email(message = "*Please provide a valid Email")
    @org.hibernate.validator.constraints.NotEmpty(message = "*Please provide an email")
    private String email;


    @Column(name = "date_of_birth", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dob;

    @Column(name = "full_names")
    @org.hibernate.validator.constraints.NotEmpty(message = "*Please provide your name")
    private String fullName;

    @Column(name = "contact_phone_number")
    @NotEmpty(message = "*Please provide your phone number")
    @Length(min = 10, max = 15)
    private String contact;

    @Column(name = "is_an_out_patient", nullable = false)
    @NotEmpty(message = "*Please specify out patient or not")
    private String out_patient;

    @Column(name = "patient_number", nullable = false)
    @org.hibernate.validator.constraints.NotEmpty(message = "*Please provide patient number")
    @JsonIgnore
    private String patient_number;


}
